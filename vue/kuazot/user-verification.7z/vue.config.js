
module.exports = {
  transpileDependencies: [
    'vuetify'
  ]
}
