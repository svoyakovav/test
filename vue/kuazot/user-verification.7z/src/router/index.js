import Vue from "vue";
import VueRouter from "vue-router";

// import List from "../components/List.vue";
// import Hello from "../components/HelloWorld.vue";

Vue.use(VueRouter);

export default new VueRouter({
  mode: "history",
  routes: [
    // {
    //   path: "/plant/shuhartApp_vue/",
    //   component: Hello,
    //   name: "Hello",
    // },

    // {
    //   path: "/plant/shuhartApp_vue/list",
    //   component: List,
    //   name: "List",
    // },
  ],
});
